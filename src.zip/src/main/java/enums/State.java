package enums;

public enum State {
    NO_SHIP,
    UNDAMAGED_SHIP,
    DAMAGED_SHIP,
    MISSED_SHIP
}
