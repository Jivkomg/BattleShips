package enums;

public enum GameState {
    NOT_READY,
    PLAYING,
    PLACING
}
